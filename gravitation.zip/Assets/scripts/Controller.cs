﻿using UnityEngine;
using System.Collections;

public class Controller : MonoBehaviour {

    Obj[] obs;
    Ray ray;
    public float G = 6.673e-11f;
    public sfloat a = new sfloat(1, 1);
    public sfloat b = new sfloat(1, 1);
    public float time = 1;
    public int fractureThreshold;   //amount of kinetic energy to fracture a mass into smaller pieces
    public int max_fractures = 4;   //maximum allowed number of fractures from high energy collisions
    public static bool combineMasses = true;
    public static int clumpThreshold = 480;
    public static int clumpLeaveThreshold = 120;
    public float randomseed = 0.5f;

    Vector3 r = Vector3.zero;
    // Use this for initialization
    // Update is called once per frame
    void Update()
    {
        Time.timeScale = time;
        if (Input.GetMouseButtonDown(0))
        {
            int n = FindObjectsOfType<Obj>().Length + 1;
            ray = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
            RaycastHit rch;
            Physics.Raycast(ray, out rch);
            Debug.Log(rch.point);
            r = rch.point;
            GameObject newMass = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            newMass.name = "mass" + n;
            newMass.GetComponent<MeshRenderer>().material = Resources.Load("planet") as Material;
            newMass.transform.localScale.Set(0.5f, 0.5f, 0.5f);
            newMass.transform.parent = transform;
            newMass.AddComponent<Rigidbody>();
            newMass.GetComponent<Rigidbody>().angularDrag = 0;
            newMass.AddComponent<TrailRenderer>();
            newMass.GetComponent<TrailRenderer>().material = Resources.Load("trail") as Material;
            newMass.AddComponent<Obj>();
            Obj O = newMass.GetComponent<Obj>();
            O.SetPosition(rch.point);
            O.mass = 9e+08f;
            O.SetVelocity(new Vector3(Random.Range(-randomseed, randomseed), Random.Range(-randomseed, randomseed), Random.Range(-randomseed, randomseed)));
        }

        obs = GetComponentsInChildren<Obj>();
        Debug.DrawRay(Camera.main.transform.position, r - Camera.main.transform.position);
        //Debug.Log(obs.Length);
        for (int i = 0; i < obs.Length; i++)
        {

            Vector3 A = Vector3.zero;

            for (int j = 0; j < obs.Length; j++)
            {
                if (obs[j] != obs[i])
                {
                    Vector3 direction = obs[j].transform.position - obs[i].transform.position;
                    float mag = direction.magnitude;
                    direction.Normalize();

                    // A = GM/r^2
                    //Debug.Log(direction.ToString() + " | " + G + " | " + obs[j].mass + " | " + Mathf.Pow(mag, 2));
                    A += direction * G * obs[j].mass * obs[i].mass / Mathf.Pow(mag, 2);
                }
            }
            //add the accumulated force
            //Debug.Log(A.ToString());
            obs[i].SetAcceleration(A);

        }
    }
    //Obj[] obs;
    //public float G = 6.673e-11f;

    //Ray ray;

    //void Start()
    //{
    //    obs = GetComponentsInChildren<Obj> ();
    //}
	
    //void Update ()
    //{
    //    //ray = Camera.main.ScreenPointToRay (new Vector3(200, 300, 0));
    //    //Debug.DrawRay (ray.origin, ray.direction * 10);

    //    for (int i = 0; i < obs.Length; i++)
    //    {
    //        Vector3 A = Vector3.zero;

    //        for (int j = 0; j < obs.Length; j++)
    //        {
    //            Vector3 direction = obs[j].transform.position - obs[i].transform.position;
    //            float mag = direction.magnitude;
    //            direction.Normalize();
    //            //Debug.Log(obs[j].mass);
    //            Debug.DrawLine(transform.position, transform.position + direction * mag);
    //            Debug.Log(mag);
    //            // A = GM/r^2
    //            if (obs[j] != obs[i])
    //                A += direction * G * obs[j].mass / Mathf.Pow(mag, 2);
    //        }

    //        //Debug.Log(A);
    //        obs[i].SetAcceleration(A);
    //    }
    //}

    void OnMouseDown()
    {
        Debug.Log(Input.mousePosition);
        ray = Camera.main.ScreenPointToRay(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0));
        RaycastHit rch;
        Physics.Raycast(ray, out rch);
        Debug.Log(rch.point);
    }

	public float GetG()
	{
		return G;
	}
}
