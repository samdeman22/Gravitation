﻿using UnityEngine;
using System.Collections;

public class MassComponent : MonoBehaviour {
	//this controls the mass of an obj
	public double mass = 1f;
	public 

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
