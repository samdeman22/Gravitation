﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Obj : MonoBehaviour {

	public Vector3 v = Vector3.zero, a = Vector3.zero;
    public float mass = 1f;
    public float trailTime = 90;
    Rigidbody rb;
    public float density = 1f;

	// Use this for initialization
	void Start ()
    {
        rb = GetComponent<Rigidbody>();
        //none of this, thank you very much
        rb.useGravity = false;
        rb.constraints = RigidbodyConstraints.None;
        rb.mass = Mathf.Abs(mass);
        transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
        Debug.Log(3 * mass / (4 * density * Mathf.PI));
        TrailRenderer tr = GetComponent<TrailRenderer>();
        GetComponent<MeshRenderer>().material.color = new Color(Random.value, Random.value, Random.value, 1f);
        Color c = GetComponent<MeshRenderer>().material.color;
        //tr.material.shader = Shader.Find("Additive");
        Debug.Log(c);
        tr.material.SetColor("_TintColor", new Color(1f - c.r, 1f - c.g, 1f - c.b, 0.1f));
        tr.time = trailTime;
        //tr.startWidth = (0.15f)*transform.localScale.magnitude;
        tr.startWidth = 0.005f;
        tr.endWidth = 0.005f;
        // m/d = (4/3) * pi * r^3
        // 3m/4dpi = r^3
        //r = 3rt(3m/4dpi)
        
	}

    Dictionary<string, int> stuck = new Dictionary<string, int>();
    Dictionary<string, int> left = new Dictionary<string, int>();
    Dictionary<string, bool> touching = new Dictionary<string, bool>();
    Dictionary<GameObject, string> clumpID = new Dictionary<GameObject, string>();
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(gameObject.name + " | " + a.ToString());        
        rb.AddForce(v, ForceMode.VelocityChange);
        v = Vector3.zero;
        rb.AddForce(a);

        //go through every key k in left entry
        // if !touching then left[k]++;
        // if left[k] > T then remove the association

        var buffer = left;

        foreach (string k in buffer.Keys)
        {
            if (!touching[k])
            {
                left[k]++;
                if (left[k] > Controller.clumpLeaveThreshold)
                {
                    Debug.Log(gameObject.name + " has left " + clumpID[gameObject]);
                    stuck.Remove(k);
                    left.Remove(k);
                    touching.Remove(k);
                    clumpID.Remove(gameObject);
                }
            }
            
        }
	}



    //void OnCollisionEnter(Collision c)
    //{
    //    if (c.gameObject.GetComponent<Obj>() != null)
    //    {
    //        if (!stuck.ContainsKey(c.gameObject.name))
    //            stuck[c.gameObject.name] = 0;

    //        stuck[c.gameObject.name]++;
    //        touching[c.gameObject.name] = true;

    //        if (stuck[c.gameObject.name] > Controller.clumpThreshold)
    //        {
    //            clumpID[gameObject] = "group" + clumpID.Count + 1;
    //            Debug.Log(c.gameObject.name + " is now a member of " + clumpID[c.gameObject]);
    //            if (Controller.combineMasses)
    //                CreateCombination(gameObject, c.gameObject);    
    //        }
    //    }
        
    //}

    //void OnCollisionStay(Collision c)
    //{
    //    if (c.gameObject.GetComponent<Obj>() != null)
    //        stuck[c.gameObject.name]++;
    //    if (stuck[c.gameObject.name] > Controller.clumpThreshold)
    //    {
    //        clumpID[gameObject] = "group" + (clumpID.Count + 1);
    //        Debug.Log(c.gameObject.name + " is now a member of " + clumpID[gameObject]);
    //        CreateCombination(gameObject, c.gameObject);
    //    }
    //}

    //void OnCollisionExit(Collision c)
    //{
    //    if (c.gameObject.GetComponent<Obj>() != null)
    //    {
    //        if (!left.ContainsKey(c.gameObject.name))
    //            left[c.gameObject.name] = 0;

    //        left[c.gameObject.name]++;
    //        touching[c.gameObject.name] = false;
    //        Debug.Log("no longer touching " + c.gameObject.name);

    //        if (left[c.gameObject.name] > Controller.clumpLeaveThreshold)
    //        {
    //            Debug.Log(c.gameObject.name + " has left " + clumpID[gameObject]);
    //            stuck.Remove(c.gameObject.name);
    //            left.Remove(c.gameObject.name);
    //            touching.Remove(c.gameObject.name);
    //            clumpID.Remove(gameObject);                
    //        }
    //    }
    //}

	public void SetAcceleration (Vector3 a)
	{
		this.a = a;
	}

	public void AddAcceleration (Vector3 a)
	{
		this.a += a;
	}

	public void SetVelocity(Vector3 v)
	{
		this.v = v;
	}

	public void AddVelocity (Vector3 v)
	{
		this.v += v;
	}

	public void SetPosition (Vector3 p)
	{
		this.transform.position = p;
	}

	public void Displace(Vector3 s)
	{
		transform.position += s;
	}

    public void CreateCombination(GameObject m1, GameObject m2)
    {
        Obj o1 = m1.GetComponent<Obj>();
        Obj o2 = m2.GetComponent<Obj>();

        if (o1 != null && o2 != null)
        {
            float newMass = o1.mass + o2.mass;
            //color = (mass1 / (totalMass)) * color1 + (mass2 / (totalMass)) * color2
            Color newColor = (o1.mass / (o1.mass + o2.mass)) * m1.GetComponent<MeshRenderer>().material.color + (o2.mass /(o1.mass + o2.mass)) * m2.GetComponent<MeshRenderer>().material.color;

            if (o2.mass >= o1.mass)
            {
                //combine the object 2 and object 1
                //remove object 1
            }
            else
            {
                //combine object 1 and object 2
                //remove object 2
            }
        }
    }

//	 void onCollisionStay(Collision c)
//	{
//		Vector3 s = c.transform.position - transform.position;
//		float mag = s.magnitude;
//		s.Normalize ();
//
//		if (c.gameObject.GetComponent<Obj>().mass > )
//		c.gameObject.GetComponent<Obj>().a -= s * controller.GetG() * mass;
//	}
}
