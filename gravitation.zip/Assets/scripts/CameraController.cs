﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {

	public float moveCoefficient = 1;
    Rigidbody rb;

	void Awake()
	{
		//Cursor.lockState = CursorLockMode.Locked;
		//Screen.fullScreen = true;
		Cursor.visible = false;
	}

	// Use this for initialization
	void Start ()
	{
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.None;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(Camera.current != null)
		{
            rb.AddRelativeForce(new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")) * moveCoefficient, ForceMode.VelocityChange);
		}
	}
}
